import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TablesComponent } from './components/tables/tables.component';
import { MenusComponent } from './components/menus/menus.component';

const routes: Routes = [
  {
    path:"",
    redirectTo:"tables",
    pathMatch:"full"
  },
  {
    path:"tables",
    component:TablesComponent
  },
  {
    path:"menus/:id",
    component:MenusComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
