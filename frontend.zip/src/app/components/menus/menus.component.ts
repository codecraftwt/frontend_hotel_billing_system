import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menus',
  templateUrl: './menus.component.html',
  styleUrls: ['./menus.component.css']
})
export class MenusComponent implements OnInit {
  tableData: any = null;
  foodListData:any=[
    {
      name:'food list 1'
    },
    {
      name:'food list 2'
    },
    {
      name:'food list 3'
    },
    {
      name:'food list 4'
    },
    {
      name:'food list 5'
    },
    {
      name:'food list 6'
    },
    {
      name:'food list 6'
    },
    {
      name:'food list 6'
    },
    {
      name:'food list 6'
    },{
      name:'food list 6'
    },{
      name:'food list 6'
    }
  ]
  foodItems=[
    {
      name:'pav bhaji',
      price:'50',
    },
    {
      name:'pav bhaji',
      price:'50',
    },
    {
      name:'pav bhaji',
      price:'50',
    },
    {
      name:'pav bhaji',
      price:'50',
    },
    {
      name:'pav bhaji',
      price:'50',
    },
    {
      name:'pav bhaji',
      price:'50',
    },
    {
      name:'pav bhaji',
      price:'50',
    },
    {
      name:'pav bhaji',
      price:'50',
    },
    {
      name:'pav bhaji',
      price:'50',
    },
    {
      name:'pav bhaji',
      price:'50',
    },
  ]
  //billing
  customerName: string = '';
  billingData: any[] = [
    { itemname: 'vadapav', price: 10, quantity: 50 },
    { itemname: 'pavbhaji', price: 5, quantity: 20 },
    { itemname: 'misal', price: 4, quantity: 40 },
    { itemname: 'misal', price: 4, quantity: 40 }
  ];
  totalAmount: number = 0;
  
  constructor(private router: Router) {
    this.updateTotal();

   }


  ngOnInit(): void {
    
  }

  getFoodList(data:any){
    console.log(data,'data');
    
  }

  updateTotal() {
    this.totalAmount = this.billingData.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }

  removeItem(index: number) {
    this.billingData.splice(index, 1);
    this.updateTotal();
  }

  pay() {
    alert(`Total amount to pay is: ${this.totalAmount}`);
  }
  
 isExpanded = false;

  toggle() {
    this.isExpanded = !this.isExpanded;
  }
}
