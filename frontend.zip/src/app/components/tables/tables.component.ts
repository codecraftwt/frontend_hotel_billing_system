import { Component, OnInit, ElementRef, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tables',
  templateUrl: './tables.component.html',
  styleUrls: ['./tables.component.css']
})
export class TablesComponent implements OnInit {

  dummyData = [
    { name: 'table 1', no_of_pepoples: '' },
    { name: 'table 2', no_of_pepoples: '' },
    { name: 'table 3', no_of_pepoples: '' },
    { name: 'table 4', no_of_pepoples: '' },
    { name: 'table 5', no_of_pepoples: '' },
    { name: 'table 6', no_of_pepoples: '' }
  ];

  showMenu: boolean = false;
  hoveredData: any = null;
  menuStyle: { [key: string]: string } = {};

  constructor(private router: Router, private elRef: ElementRef, private renderer: Renderer2) { }

  ngOnInit(): void {
  }

  onTableClick(data: any) {
    // this.router.navigate(['/menus'], { queryParams: { name: data.name } });
    this.router.navigate(['/menus/2']);
  }

  onMouseEnter(data: any) {
    this.showMenu = true;
    this.hoveredData = data;
    setTimeout(() => {
      const tableElement = this.elRef.nativeElement.querySelector('.tableStructured');
      const menuElement = this.elRef.nativeElement.querySelector('.custom-menu');
      const tableRect = tableElement.getBoundingClientRect();
      this.menuStyle = {
        top: `${tableRect.top}px`,
        left: `${tableRect.right + 10}px` // 10px offset from the right edge of the table
      };
    }, 0);
  }

  onMouseLeave() {
    this.showMenu = false;
    this.hoveredData = null;
  }
}
